# Introduction 
This is simple project to show Ansible within Azure usage. It was created for DevOps Wroclaw MeetUp purposes. Presented at 02-2020 DevOps MeetUp Wroclaw hosted by Avanade. 

# Getting Started
Two ADO piplines are defined here:
1. [azure-pipelines](./azure-pipelines.yml) - one to provision infra (via Ansible), build demo application (ReactJS on front-end, NodeJs on back-end) and deploy it to the provisioned Azure resources. 
2. [azure-manage](./azure-manage) - additional one to handle environment(s) deletion.

# Build and Test
Attach pipelines to the Azure DevOps. Make sure you're providing credentials to the Azure Service Principal within the each pipeline. Aditional ```environment_name``` variable is required for both pipelines and ```vm_admin_pass``` variable for [azure-manage](./azure-manage.yml).

# Contribute
Project is just a show-case. No further development is planned.