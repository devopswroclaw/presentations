import React from 'react';
import logo from './logo.png';
import './App.css';

const API = process.env.REACT_APP_API_URL
const listPartsEndpoint = "/list-participants"
const addPartEndpoint = "/add-participant"

async function getPartsList() {
  const res = await fetch(API + listPartsEndpoint);
  const data = await res.json();
  return data;
}

function Logo() {
  return (
    <img src={logo} className="App-logo" alt="logo" />
  );
}

function PartsDisplay(props) {
  return (
    <h1>Participants: {props.count}</h1>
  );
}

class PartsAdder extends React.Component {
  state = {
    fname: '',
    company: ''
  };

  handleInputChange = (event) => {
    const { target: { name, value } } = event;
    this.setState({ [name]: value });
  }

  handleSubmit = async (event) => {
    event.preventDefault();
    event.stopPropagation();
    const { fname, company } = this.state;
    await fetch(API + addPartEndpoint, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify({ fname, company })
    });
    window.location.reload(false);
  }

  render() {
    return (
      <form onSubmit={this.handleSubmit}>
        <div className="text-input">
          <input name="fname" type="text" placeholder="First name" onChange={this.handleInputChange} value={this.state.fname}></input>
        </div>
        <div className="text-input">
          <input name="company" type="text" placeholder="Company name" onChange={this.handleInputChange} value={this.state.company}></input>
        </div>
        <div className="submit-input">
          <input type="submit" value="Add me!"></input>
        </div>
      </form>
    );
  }

}

function createTable(partsList) {
  return partsList.map((participant, index) => (
    <tr key={index}>
      <td key="fname">{participant.fname}</td>
      <td key="company">{participant.company}</td>
    </tr>
  ));
}

function PartsList(props) {
  if (props.partsList.length > 0) {
    return (
      <table>
        <thead>
          <tr>
            <th>First name</th>
            <th>Company</th>
          </tr>
        </thead>
        <tbody>
          {createTable(props.partsList)}
        </tbody>
      </table>
    )
  }
  return <div />
};

class App extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      parts: [],
    };
  }

  async componentDidMount() {
    const data = await getPartsList();
    this.setState({ parts: data });
  }

  render() {
    return (
      <div className="App">
        <Logo />
        <PartsDisplay count={this.state.parts.length} />
        <PartsAdder />
        <PartsList partsList={this.state.parts} />
      </div>
    );
  }

}

export default App;
