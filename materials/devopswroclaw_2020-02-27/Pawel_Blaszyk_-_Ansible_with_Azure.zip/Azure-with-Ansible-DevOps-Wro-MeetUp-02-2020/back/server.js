const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const MongoClient = require('mongodb').MongoClient;
const assert = require('assert');

const mongoURL = process.env.DB_CONNECTION_STRING
const dbName = 'meetup-app'
const docName = 'participants'

const mongoClient = new MongoClient(mongoURL, {useUnifiedTopology: true});

mongoClient.connect(function (err) {
    assert.equal(null, err);
    console.log('Connected to mongoDB successfully')
})

const db = mongoClient.db(dbName);
const collection = db.collection(docName);

const getParticipantsFromDb = (collection, callback) => {
    collection.find({}).toArray((err, docs) => {
        assert.equal(null, err);
        console.log('Participants read from DB:');
        console.log(docs);
        callback(docs);
    })
}

const writeParticipantToDb = (collection, doc, callback) => {
    collection.insertOne(doc, (err, result) => {
        assert.equal(null, err);
        console.log('New participant added:');
        console.log(`First name: ${doc.fname} --- Company: ${doc.company}`);
        callback(result);
    });
}

const app = express();
const port = process.env.PORT || 4000;

const whitelist = [process.env.FRONT_URL]
var corsOptions = {
  origin: function (origin, callback) {
    if (whitelist.indexOf(origin) !== -1) {
      callback(null, true)
    } else {
      callback(new Error('Not allowed by CORS'))
    }
  }
}

app.use(cors(corsOptions));
app.use(bodyParser.json());

app.get('/list-participants', function (req, res) 
{   getParticipantsFromDb(collection, (parts) => {
        res.json(parts);
    })
})

app.post('/add-participant', function (req, res) {
    writeParticipantToDb(collection, req.body, (result) => {
        console.log(`Partcipant added with _id ${result.insertedId}`);
    })
    res.end()
});

app.listen(port, function () {
    console.log(`meetup-app back-end listening on port ${port}!`);
})